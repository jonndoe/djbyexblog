VERSION = (1, 2, 0)
__version__ = ".".join(str(i) for i in VERSION)

default_app_config = "taggit.apps.TaggitAppConfig"
